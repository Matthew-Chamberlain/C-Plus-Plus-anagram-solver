//***********************************************************************************************
//4COM1037 – Anagram Solver Challenge
//Student ID: 17038003
//This program including all the code is my own work and has been tested fully before submission
// **********************************************************************************************

#include <iostream> //declares the standard devices cin, cout, clog, cerr
#include <string> //declares string types and conventions including begin & end iterator
#include <algorithm> //declares a collection of ranged functions
#include <fstream> //declares a set of standard file stream devices that can be used to to create, read and use files
#include <ctime> //declares a set of functions, macros and types to work with date and time information, e.g. the time() function is used to get the current time
#include <list> // includes the library that allows the use of lists and list operations

#define cDATAFILE "Words_75K_PreSubmissionTesting.csv" //create a fixed identifier (a bit like an unchangeable global variable) with a string value; the compiler will automatically use the string for each instance of the identifier 

using namespace std; ; //tell the compiler that by default to use the “std” – this means that we don’t need to keep saying “std::cout” we can just use: “cout”

// The purpose of this function is to get input from the user and return their value so it can be used in another functions. The function expects no values and returns a string value.
string GetWord(){
  string localString; // defines a string variable called localString, which will be used to hold the users word
  cout << endl << "Please enter a new word or phrase: "; // prompts the user to enter a word by outputing a message to the user
  getline(cin >> ws, localString); // this line gets the input of the user and stores it in the localString variable, ws is used to ensure that the users input keeps being read even after a white space character.
  cout << endl; // used to insert a line break
  return localString; // returns the users word contained in localString to the function that called GetWord().
}

// The purpose of this function is to take in a string variable and return the fully lowercase version of the string. this is ensential for sorting which will be necessary for finding anagrams and for finding the longest word.
string ToLower(string originalString){
  string localString = originalString; // defines a string variable called localString and assigns it the value of the users word that was parsed into the function in the variable originalString
  for(int i = 0; i < localString.length(); i++){ // loops as many times as there are characters in the string localString
    localString[i] = tolower(localString[i]); // for every character in the string calls the inbuilt tolower function on that character and stores the lower case character back in the original characters position
  }
  return localString; // returns the lowercase word stored in the localString variable to the function that called the ToLower function.
}

// The purpose of this function is to sort a string that is parsed into the function to alphabetical order, which is needed for finding anagrams and also to get the intersection of two strings for finding the longest word
string OrderWord(string originalString){
  string localString = originalString; // defines a string variable called localString and assigns it the value of originalString which is the users word that was parsed into the function
  localString = ToLower(localString); // calls the ToLower function parsing the localString variable and storing the result in the localString variable
  sort(localString.begin(), localString.end()); // calls the inbuilt sort function to sort the localString variable in alphabetical order, to do this the sort function needs to know the beginning and end of the string
  return localString; // returns the variale localString, which contains the sorted string, tp the function that called the OrderWord function
}
// The purpose of this function is to find and output any anagrams of the users word that are contained withing the specified file. The function expects a string value, which is the users word, and returns no value.
void FindAnagrams(string originalString){
  int counter = 0; // initiates an integer variable and assigns it the value of 0
  string localString = originalString; // initiates a string variable and assigns it the value of originalString, the users word that was parsed into the function
  string fileWord, orderedFileWord, orderedLocalString; // defines a number of string variables with no values. fileWord will be used to store the current word of the file. orderedFileWord will be used to store the ordered version of fileWord and orderedLocalString, will be used to store the ordered version of the users word
  ifstream dbFile; ; //create a special variable (actually a class (e.g. object with its own functions) that is defined in the <fstream> header that can be used to "stream" (read) info from files

  localString = ToLower(localString); // calls the ToLower function parsing the localString variable and storing the result in the localString variable, this is needed as all the words in the file are lowercase and the users word will need to be checked against the fileword to see whether they are the same value to ensure that the function does not include the originalString as an anagram of itself.
  orderedLocalString = OrderWord(localString); // calls the OrderWord function parsing the localString variable and storign the result in the orderedLocalString variable. This value will be needed to check if the users word and the fileWord are anagrams
 
  dbFile.open(cDATAFILE); //use the 'special' variable (object's) method (a.k.a. function) called 'open' with the name of the file to access; in this case use the value defined as cDATAFILE. Once opened the computer will put a lock of the file meaning that if someone tries to open 'this' specific file they will be told it is already in use


  while(!dbFile.eof()){ // this loop continues looping until it reaches the end of the file
    getline(dbFile, fileWord); // stores the value on the current line of the file in the fileWord variable
    orderedFileWord = OrderWord(fileWord); // calls the OrderWord function parsing the fileWord variable and stores the result in the orderedFileWord variable

    if(orderedFileWord == orderedLocalString && localString != fileWord){ // this if statment runs the indented code if the users word and the fileword and anagrams of eachother and are not the same word. It does this by checking wether orderedFileWord is equal to orderedLocalString as if two words are anagrams when in order they will be identical strings. In addition the condition localString != fileWord also needs to be met to ensure the program doesnt output the users word as an anagram of itself, when both the conditions are met the indented code is run
      cout << endl << fileWord; // outputs each anagram on a separate line
      counter++; // increments the counter variable
    }
  }
  dbFile.close(); //close the connection to the file (otherwise the file will remain locked to other users and this program)
  cout << endl << endl << "Number of anagrams found: " << counter; // after all the anagrams have been printed outputs a message using the counter to inform the user how many anagrams are in the file
  cout << endl << endl; // used to insert two line breaks
}

// the purpose of this function is to scan the specified file and output the largest word that can be made from as many letters as possible of a string that the user provides. To do this the function takes in a string value, the users word and returns no value
void LargestWordAvailable(string originalString){
  int counter = 0; // initiates an int variable called counter and assigns it the value of 0, this will be used to show the user how many other words of equal length can be found in the file.
  string localString = originalString; // initialises a string variable and assigns it the value of originalString, the users word that was parsed into the function
  string fileWord, stringIntersection, orderedFileWord, orderedLocalString; // defines a number of string variables. fileWord will be used to hold the current word of the file, stringIntersection will be used to hold the intersection of the current file word and the users string, the intersection is the letters that appear in both strings, orderedFileWord will be used to store the current file word sorted in alphabetical order and orderedLocalString will be used to hold the users word sorted in alphabetical order
  string longestWord = ""; // initialises a string variable called longestWord and sets it the value of an empty string
  ifstream dbFile; //create a special variable (actually a class (e.g. object with its own functions) that is defined in the <fstream> header that can be used to "stream" (read) info from files

  orderedLocalString = OrderWord(localString); // calls the OrderWord function parsing the users word stored in localString and storing the result in the orderedLocalString variable as two words need to be in alphabetical order in order to correctly find the intersection

  dbFile.open(cDATAFILE); //use the 'special' variable (object's) method (a.k.a. function) called 'open' with the name of the file to access; in this case use the value defined as cDATAFILE. Once opened the computer will put a lock of the file meaning that if someone tries to open 'this' specific file they will be told it is already in use

  // this loop will run until it reaches the end of the function
  while(!dbFile.eof()){
    getline(dbFile, fileWord); //gets the current line of the file and stores it in the fileWord variable

    orderedFileWord = OrderWord(fileWord); // calls the OrderWord function parsing the fileWord variable and storing the result in the orderedFileWord variable as two words need to be in order to correctly find the intersection

    set_intersection(orderedLocalString.begin(), orderedLocalString.end(), orderedFileWord.begin(), orderedFileWord.end(), back_inserter(stringIntersection)); // calls the set intersection function to find the intersection of the orderedLocalString variable and the orderedFileWord variable. To do this the function needs to know the beginning and end of each string and a string variable where the result can be inserted, in this case that variable is stringIntersection

    if(fileWord.length() == longestWord.length() && stringIntersection == orderedFileWord){ // this if statement is used to increment the counter used to show how many other words of equal length appear in the file. it does this by checking wether the length of fileWord is equal to the length of the longest word and by checking the fileWord can be made using the letters in the users provided, by seeing wether the stringIntersection variable is equal to the orderedFileWord variable. This is because if a word can be made using the letters the user provided the intersection and the ordered word will be identical. when both of these condition are met the counter is incremented 
      counter++;
    }

    if(stringIntersection == orderedFileWord && fileWord.length() > longestWord.length()){ // this if stament is used to assign a new largest word. it does this by checking wether the stringIntersection variable is equal to the orderedFileWord variable as this shows that every character of the fileWord appears in the users string. in addition it checks to see wether the length of the file word is longer than the current longest word. this needs to come after the counter is incremented as if it came after if the longest word was updated, fileWord and longestWord would be the same and thus have the same length so the counter would be incremented everytime a new longest word is chosen and would end up being 1 greater than it should be.
      longestWord = fileWord; // sets the longest word variable equal to the fileWord variable
      counter = 0; // resets the counter as there is a new longest word so there is currently no words of equal length found
    }
    stringIntersection = ""; // sets the stringIntersection variable to an emptry string as the set_intersection function concaternates strings together rather than overwriting the value of the variable.
  }
  dbFile.close(); //close the connection to the file (otherwise the file will remain locked to other users and this program)
  cout << endl << "Longest word using letters provided: " << longestWord << endl; // outputs, with a message, the longest word in the file that could made using as many of the letters as possible in the users string using the longestWord variable
  cout << "Number of other words of equal length: " << counter << endl << endl; // outputs with a message the number of words of equal length to the longest word appear in the file that can be made using as many of the letters as possible from the users string.
}

// the purpose of this funtion is to scan through the file and output all words that are three letters and are also anagrams, it expects no values and returns no values 
void FindAll3LetterAnagrams(void){
  string fileWord, orderedCurrentWord, previousWord, orderedListWord; // defines a number of string variables
  ifstream dbFile; //create a special variable (actually a class (e.g. object with its own functions) that is defined in the <fstream> header that can be used to "stream" (read) info from files
  list<string> threeLetterWords, anagrams;  // creates two list variables one to hold all the three letters words from the text file and one to hold all of the anagrams.

  dbFile.open(cDATAFILE); //use the 'special' variable (object's) method (a.k.a. function) called 'open' with the name of the file to access; in this case use the value defined as cDATAFILE Once opened the computer will put a lock of the file meaning that if someone tries to open 'this' specific file they will be told it is already in use

  // this loop keeps looping until it reaches the end of the file
  while(!dbFile.eof()){
    getline(dbFile, fileWord); //gets the current line of the file and stores the value in the fileWord variable 
    if(fileWord.length() == 3){ // this if statment puts the fileWord variable in the bac of the threeLetterWords list if the length of the word is equal to 3
      threeLetterWords.push_back(fileWord); 
    }
  }
  dbFile.close(); ;//close the connection to the file (otherwise the file will remain locked to other users and this program)

  // creates a list iterator i and loops sets it equal to the begining of the list. The loop will keep looping until the iterator reaches the end of the list.
  for(list<string>::iterator i = threeLetterWords.begin(); i != threeLetterWords.end(); i++){
    orderedCurrentWord = OrderWord(*i); // calls the OrderWord function parsing the word that the iterator i is pointing to in the list and stores the result in the orderedCurrentWord variable.
    // creates a list iterator j and sets it equal to to the begining of the list. The loop will keep looping until the iterator reaches the end of the list. By using a nested for every element of the threeLetterWords list, the program loops through the threeLetterWords list and checks for anagrams. This saves much more time than looping through the whole file for every three letter word and checking for anangrams as that would result in checking three letters words against words that are shorter or longer than three letters
    for(list<string>::iterator j = threeLetterWords.begin(); j != threeLetterWords.end(); j++){
      orderedListWord = OrderWord(*j); // calls the OrderWord function parsing the string in the list that the iterator j is pointing to and stores the result in the orderedListWord variable
      if(orderedCurrentWord == orderedListWord && *i != *j){ // this if statement checks to see whether the words i and j point to are anagrams of eachother and that they are not the same word, if both conditions are met the indented code is run
        if(find(anagrams.begin(), anagrams.end(), *i) != anagrams.end() == false){ // this if statement adds the word the iterator i is pointing to the back of the anagrams list if it is not already in the list. The list is checked using the find function to see wether the word appears in the list.
          anagrams.push_back(*i);
        }
        if(find(anagrams.begin(), anagrams.end(), *j) != anagrams.end() == false){ // this if statement adds the word the iterator j is pointing to the back of the anagrams list if it is not already in the list. The list is checked using the find function to see wether the word appears in the list.
          anagrams.push_back(*j);
        }
        // the if statments are needed to ensure that there are no duplicates that appear in the list as if A is an anagram of B, B is an anagram of A and so each word will be added twice, once when i points to A and once when i points to B.
      }
    }
  }
  //loops through all the elements of the anagrams list by creating an iterator that is equal to the begining of the list and stops when it reaches the end. The purpose of the loop is to print out each sequence of the anagrams 
  for(list<string>::iterator i = anagrams.begin(); i != anagrams.end(); i++){
    previousWord = OrderWord(previousWord); // calls the OrderWord function parsing the previousWord vaariable and storing the result back in the previousWord variable
    orderedListWord = OrderWord(*i); // calls the OrderWord function parsing the string in the list that the iterator i points to and stores the result in the orderedListWord variable 
    if(orderedListWord != previousWord){ // checks wether the previous word and the current word of the list are anagrams of eachother, if they are, create a line break. This is so that each sequence of anagrams appear on a different line
      cout << endl;
    }
    previousWord = *i; // sets the previous word variable equal to the string in the list that i points to. The assignment needs to take place after the check so the previous word variable always contains the element from the previous iteration
    cout << *i << " "; // this line prints out the string in the list that i points to
  }
  if(anagrams.empty() == true){ // this if statement checks to see wether the anagrams list is empty, if it is the program prints out a message informing the user
    cout << endl << "There are no three letter anagrams" << endl;
   
  }
  cout << endl << endl; // used to insert two line breaks
}

// the purpose of this function is to output all five letter anagrams from a text file. It expects no values and returns no values. The code of this function is almost identical to the function above that outputs all three letter anagrams above. The only difference is that it adds words from the file to the list if there length is 5 letters instead of three letters
void FindAll5LetterAnagrams(void){
  string fileWord, orderedFileWord, orderedCurrentWord, previousWord, orderedI;
  ifstream dbFile;
  list<string> fiveLetterWords;
  list<string> anagrams;

  dbFile.open(cDATAFILE);

  while(!dbFile.eof()){
    getline(dbFile, fileWord);
    if(fileWord.length() == 5){
      fiveLetterWords.push_back(fileWord);
    }
  }
  dbFile.close();
  for(list<string>::iterator i = fiveLetterWords.begin(); i != fiveLetterWords.end(); i++){
    orderedCurrentWord = OrderWord(*i);
    for(list<string>::iterator j = fiveLetterWords.begin(); j != fiveLetterWords.end(); j++){
      orderedFileWord = OrderWord(*j);
      if(orderedCurrentWord == orderedFileWord && *i != *j){
        if(find(anagrams.begin(), anagrams.end(), *i) != anagrams.end() == false){
          anagrams.push_back(*i);
        }
        if(find(anagrams.begin(), anagrams.end(), *j) != anagrams.end() == false){
          anagrams.push_back(*j);
        }
      }
    }
  }
  for(list<string>::iterator i = anagrams.begin(); i != anagrams.end(); i++){
    previousWord = OrderWord(previousWord);
    orderedI = OrderWord(*i);
    if(orderedI != previousWord){
      cout << endl;
    }
    previousWord = *i;
    cout << *i << " ";
  }
  if(anagrams.empty() == true){
    cout << endl << "There are no five letter anagrams" << endl;
  }
  cout << endl << endl;
}
// the purpose of this function is to allow the user to exit the program, the function expects no values and returns no values
void QuitNow(void){
  string localString; // initiates a string variable called localString
  cout << endl << "Are you sure (Y/N)? "; // outputs a message to the user asking them wether they want to quit or not
  cin >> localString; // gets input from the user and stores it in the localString variable
  cout << endl; // outputs a line break
  if(localString == "Y" || localString == "y" || localString == "Yes"){ //exits the program if the user input one of the valid inputs
    exit(EXIT_SUCCESS);
  }  
}

// this function is used to show the options to the user and allows the user to select the options. The function also display how long each function takes to run each function except the getWord function as the length of that function is dependent on how long the user takes to input their word
void Menu(){
  string currentString = "alert"; // creates a string variable called currentString and gives it the default value of "alert"
  string input; // creates a string variable called input
  int menuOption, startTicks, stopTicks, totalTicks; // creates 4 integer variables, menuOption, startTicks, stopTicks and totalTicks
  float timeMilliseconds = 0; // creates a float variable called timeMilliseconds and assigns it the value 0
  
  do{ // the do while loop runs the code at least once and then repeats it depending on wether a specific condition is met
    
    // outputs a number of messages that display the menu and different options, /t is used to indent a line of text and /n is used to put the text on a new line
    cout << "C++ Anagram Solver Challenge" << endl << endl; 
    cout << "\t1. Enter a word or phrase (current word/phrase is: " << currentString << ")." << endl; // this line also displays the users word by outputting the currentString variable
		cout << "\t2. Find an anagram of the word." << endl;
    cout << "\t3. Find the largest word containing (most of) these letters." << endl;
    cout << "\t4. Find all possible 3 letter words that are also anagrams." << endl;
    cout << "\t5. Find all possible 5 letter words that are also anagrams" << endl << endl;
		cout << "\t0. Quit the program." << endl;

    cout << "\n\tTime taken to complete the last function was: " << timeMilliseconds << "ms" << endl; //this line also display the time taken for the function to be completed by printing the timeMilliseconds variable
    cout << "\nPlease enter a valid option (1 - 5 or 0 to quit): ";
    
    getline(cin >> ws, input); // this line gets the input of the user and stores it in the input variable, ws is used to ensure that the users input keeps being read even after a white space character.
    menuOption = atoi(input.c_str()); // converts the value of input to an intenger and stores it in the menuOption variable
    if(isdigit(input[0]) == false || input.length() != 1){ // if the value that the user enters is an not a digit or is longer than 1 character set the menu option to -1, so ther error message can be displayed. The menuOption variable needs to be set to an invalid number because if the conversion from string to int fails it will set return 0 and 0 is one of the valid option
      menuOption = -1;
    }
    if(menuOption < 0 || menuOption > 5){ // prints and error message containg the user invalid input if the user enters a value that does not correspond to one of the options
      cout << "\nUnfortunately, \'" << input <<"\' is not a valid option, please try again. \n\n";
    }
    
    // this switch statement is used to run a different section of code depending on the value of the menu Option variable
    switch(menuOption){
      // if menu option is equal to 1 run the indented code
      case 1:
          currentString = GetWord(); // calls the GetWord function and stores the result in the currentString variable
          timeMilliseconds = 0; // sets the timeMilliseconds variable to 0 as the timer should not display a value when the GetWord function is called as the time taken to complete the function is mainly dependant on the user
        break;

      // if menu option is equal to 2 run the indented code
      case 2:
          startTicks = clock(); // sets the startTicks variable equal to the number of clock ticks since the program was started 
          FindAnagrams(currentString); // calls the FindAnagrams function parsing the currentString variable
          stopTicks = clock(); // set the stopTicks variable equal to the number of clock ticks since the program was started
          totalTicks = stopTicks - startTicks; // sets the total ticks variable equal to the difference in clock ticks from when the function was completed and when the function was called
          timeMilliseconds = totalTicks/double(CLOCKS_PER_SEC) * 1000; // converts the clock ticks to seconds and then multiplies the value by 1000 to put the result in milliseconds and store the result in the timeMilliseconds variable
        break; // used to exit the switch statement 
      // if menu option is equal to 3 run the indented code

      case 3:
          startTicks = clock();
          LargestWordAvailable(currentString); //calls the LargestWordAvailable function parsing the currentString variable 
          stopTicks = clock();
          totalTicks = stopTicks - startTicks;
          timeMilliseconds = totalTicks/double(CLOCKS_PER_SEC) * 1000;
        break; // used to exit the switch statement 
      
      // if menu option is equal to 4 run the indented code
      case 4:
          startTicks = clock();
          FindAll3LetterAnagrams(); // calls the FindAll3LetterAnagrams function
          stopTicks = clock();
          totalTicks = stopTicks - startTicks;
          timeMilliseconds = totalTicks/double(CLOCKS_PER_SEC) * 1000;
        break; // used to exit the switch statement 

      // if menu option is equal to 5 run the indented code
      case 5:
          startTicks = clock();
          FindAll5LetterAnagrams(); // calls the FindAll5LetterAnagrams function
          stopTicks = clock();
          totalTicks = stopTicks - startTicks;
          timeMilliseconds = totalTicks/double(CLOCKS_PER_SEC) * 1000;
        break; // used to exit the switch statement

      // if menu option is equal to 0 run the indented code
      case 0:
          QuitNow(); // calls the QuitNow function
          timeMilliseconds = 0; // sets the timeMilliseconds variable to 0 as the timer should not display a value when the GetWord function is called as the time taken to complete the function is mainly dependant on the user
        break; // used to exit the switch statment 
    }

  }while(true); // keeps looping the do while loop while true is equal to true. This means that the menu will loop endlessly until the user calls the quitnow function and inputs a valid quit option
}

// the main function is the function that is run as soon as the program is run
int main() {
  Menu(); // calls the Menu function
}

/* Test Log
	*****************************************************************************************
	Test Date, Use & Operations, Description, What did you test, Results, Reflections			
	*****************************************************************************************
  6/3/19 Menu function - The menu was printed out to the user in the layout that the assignment brief specified with the correct default values. - Passed
  6/3/19 Menu function - after each of the function have completed execution the time taken to complete the function is calculated using by getting the difference between the number of clocks ticks after and before the function was called. This value was then converted to milliseconds and displayed on the menu. - Passed
  6/3/19 Menu function - If the user enters a number option that is invalid it will output the correct error message, however if the user enters an alphabet character or string for the menu option it will output the wrong message: "Unfortunately, '0' is not a valid option, please try again.". I believe this happens due to the fact that the program is trying to put the users input into the menuOption variable which is an integer and if the user enters an alphabet character or string the program cannot store the result and instead returns a 0, however this is a problem as the quit option is option 0. To fix this problem I believe I should store the users input as a string and convert it to an int, if the conversion cannot take place the menuOption variable should be set to an integer outside the range of accepted values and the error message should display the users string. - Failed
  6/3/19 GetWord function - When the user entered a menu option of 1, the GetWord function was called and the user was able to enter a word or phrase, this word or phrase was then returned and displayed in the menu. - Passed
  6/3/19 QuitNow function - When the user enters a menu option of 0 the QuitNow function is called. If the user enters one of the valid option, either "y", "Y" or "Yes", the program will exit, otherwise the program will go back to the menu function. - Passed
  7/3/19 FindAnagrams function - When the user entered a menu option of 2, the FindAnagrams function was called parsing the users word. The function then scanned the file for anagrams of the users word and printed them out to the user. additionally the users word is not printed as an anagram of itself if it is contained in the file. at the end of the function the number of anagrams is also printed out to the user.
  7/3/19 LargestWordAvailable function - When the user entered a menu option of 3 the LargestWordAvailable function was called parsing the users string, however it did not output the largest word that could be made using as many of letters as possible. I believe this is because I am trying to use the find function to see if the word in the file is a substring of the users string however for a word to be a substring the letters and positions need to be the same and this will almost never be the case. it is much more likely that all the letters of a word appear in the users string but at different locations within the strings. To fix this issue I believe I will have to use a function that will find the intersection between the two strings like they were sets of letters, as the intersection will find all letters in common between the two strings regardless of the positions. - Failed
  7/3/19 LargestWordAvailable function - Using the set_intersection inbuilt function I have been able to find the longest word by checking wether the users ordered word is equal to the ordered intersection this is because if a word appears in the users string all the letters in the word will appear in the string and the intersection will be the word itself. Additionally the function also outputs how many other words their are of equal length that appear in the file that can be made using the characters in the user's string. - Passed
  13/3/19 FindAll3LetterAnagrams function - To find all three letter anagrams I called the FindAnagrams function on every three letter word in the file. This is a very bad solution as it means every three letter word is being checked against all words in the file. This results in time being wasted checking if three letter words are anagrams of words with more or less than three letters. Additionally it will output that some three letter words have no anagrams and will print out lots of duplicates. A much better solution would be to only check every three letter word against every other three letter to word to check if its an anagram - Failed
  13/3/19 FindAll3LetterAnagrams function - The program now puts all three letter words in a list and for every element of the list loops through the list and checks for anagrams. Any anagrams are then added to a second list as long as they are not already in the list so there are no duplicates. Each sequence of anagrams are then printed in an ordered fashion. - Passed
  13/3/19 FindAll5LetterAnagrams function - The program scans the file and ouptuts all words that are also 5 letter anagrams in an ordered sequence. - Passed
  14/3/19 Menu function - The users input is now stored in a string and checked to see wether the string is a digit or longer than 1 character. If the users input is a single digit character it is checked wether it is in the range of accepted inputs. If it is outside the range or the users input was not a digit or longer than 1 character an error message is displayed using the string variable so the users input is always displayed correctly. - Passed
  6/3/19 Menu Function - After each function or invalid input the menu was displayed endlessly. This would only stop if the user chooses the quit option and inputs a valid input causing the program to terminate. - Passed
*/